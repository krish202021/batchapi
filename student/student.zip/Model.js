const express = require('express');
const connect = require('../connection/db_connect');
const connection = connect.con;
var jwt = require('jsonwebtoken');
const jwt_verify = require('../jwt/jwt_helper');


exports.get_student_image = function (req, res, next) {
  res.setHeader('Content-Type', 'application/json');
  console.log('hello', jwt_verify.verifys(req.headers['authorization']));
  console.log('hello', req.body);
  
    var sql = `SELECT image, full_name, id FROM user where school_collage='${req.body.school_collage}' AND batch_year='${req.body.batch_year}' AND school_area_pin='${req.body.school_area_pin}' LIMIT 0, 9`;
      console.log(sql);
      connection.query(sql, function (err, result, fields) {
          if (err) {
          throw err;
          } else {
          res.send(JSON.stringify({ result }));
          }
      })
  
};

exports.get_school = function(req, res, next){
  res.setHeader('Content-Type', 'application/json');
  var sql = `SELECT * FROM school where school_area_pin LIKE '%${req.body.pinCode}%' `;
  //console.log(req.body.pinCode)
  connection.query(sql, function (err, result, fields) {
      if (err) {
      throw err;
      } else {
      res.send(JSON.stringify({ result }));
      }
  })
}

exports.get_register_student = function(req, res, next){
  res.setHeader('Content-Type', 'application/json');
  var sql = `SELECT * FROM user LIMIT 9 `;
  //console.log(req.body.pinCode)
  connection.query(sql, function (err, result, fields) {
      if (err) {
      throw err;
      } else {
      res.send(JSON.stringify({ result }));
      }
  })
}

exports.get_student_detail = function(req, res, next){
  res.setHeader('Content-Type', 'application/json');
  var sql = `SELECT * FROM user where id=${req.body.id} `;
  console.log(req.body)
  connection.query(sql, function (err, result, fields) {
      if (err) {
        throw err;
      } else {
        res.send(JSON.stringify({ result })); 
      }
  })
} 

exports.update_student_detail = function(req, res, next){
  res.setHeader('Content-Type', 'application/json');
  console.log(req.body);
  var data = req.body;
  var sql = `UPDATE user set full_name='${data.full_name}', school_collage='${data.school_collage}', city='${data.city}', country='${data.country}',
    batch_year='${data.batch_year}', image	='${data.image}', profesion	='${data.profesion}', company_name = '${data.company_name}', job_position	='${data.job_position}' where id = '${data.id}'`;
    console.log(sql);
    connection.query(sql, function (err, result, fields) {
        if (err) {
        throw err;
        } else {
        res.send(JSON.stringify({ result }));
        }
    })
}

exports.get_school_name = function(req, res, next){
  res.setHeader('Content-Type', 'application/json');
  console.log(req.body);
  var data = req.body;
  var sql = `select * from school where school_area_pin = '${req.body.school_area_pin}'`;
    console.log(sql);
    connection.query(sql, function (err, result, fields) {
        if (err) {
        throw err;
        } else {
        res.send(JSON.stringify({ result }));
        }
    })
}

exports.get_state = function(req, res, next){
  res.setHeader('Content-Type', 'application/json');
  var sql = `SELECT * FROM state`;
  console.log(req.body)
  connection.query(sql, function (err, result, fields) {
      if (err) {
        throw err;
      } else {
        res.send(JSON.stringify({ result })); 
      }
  })
} 

exports.get_city = function(req, res, next){
  res.setHeader('Content-Type', 'application/json');
  var sql = `SELECT * FROM city where state_id = ${req.body.id}`;
  console.log(req.body)
  connection.query(sql, function (err, result, fields) {
      if (err) {
        throw err;
      } else {
        res.send(JSON.stringify({ result })); 
      }
  })
} 