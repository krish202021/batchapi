import react, { useEffect, useState } from "react";
import '../App.css';
import Header from './include/Header';
//import axios from 'axios';
import { BrowserRouter as Router, Switch, Route, Link, Redirect, useHistory } from 'react-router-dom';
import * as API from '../API/Fetch';
import * as MESSAGE from './include/Message';
import Message from './Message';
import { useForm } from "react-hook-form";
import {RegisterStudents} from './RegisterStudents';
import { Audio, Hearts, Watch } from 'react-loader-spinner';
import Popup from './include/Popup';
import { useSelector, useDispatch } from "react-redux";
import school_list from "../reducer/school_list";
import FlashMessage from 'react-flash-message';
import { ErrorMessage } from '@hookform/error-message';
import TextField from '@mui/material/TextField';
import Stack from '@mui/material/Stack';
import Autocomplete from '@mui/material/Autocomplete';
const Register = () => {
    const get_school = useSelector((state)=>state.getSchool);
    const history = useHistory();
    const { register, handleSubmit, reset, formState: { errors } } = useForm();
    const [errorMessage, setErrorMessage] = useState('');
    const [stateError, setStateError] = useState('');
    const [succMessage, setSuccMessage] = useState(false);
    const [spinner, setSpinner] = useState(false);
    const dispatch = useDispatch();
    const [emailVHtml, setEmailVHtml] = useState(false);
    const [userdata, setUserdata] = useState();
    const [succMessageotp, setSuccMessageotp] = useState(false);
    const [otpsave, setOtpsave] = useState();
    const [otpw, setOtpw] = useState();
    const [registermsg, setRegistermsg] = useState(false)
    const [schoole_data, setSchoole_data] = useState([])
    const [state_data, setState_data] = useState([])//new code
    const [city_data, setCity_data] = useState([])//new code
    const [state_id, setState_id] = useState();//new code
    useEffect(() => {
        if(sessionStorage.getItem('user_id')){
            history.push({
                pathname:  "/home",
            })
        }else{
            history.push({
                pathname:  "/",
            })
        }
        //get school name
        const pin = {'school_area_pin':localStorage.getItem('pin_code')}
        API.api(pin,'student/get-school-name').then(res => {
            if(res){
                console.log('schoole_detail', res.result)
                setSchoole_data(res.result)
            }
          })

          //new code
          

          API.api(pin,'student/get-state').then(res => {
            if(res){
                console.log('city',)
                setState_data(res.result)
                const st_id  = {'id':res.result[0].id}
                API.api(st_id,'student/get-city').then(res => {
                    if(res){
                        setCity_data(res.result)
                    }
                })
            }
          })

          
            

          //end new
        
    },[]);

    const onSubmit = (data) => {
        if(state_id==''){
            setStateError("Please Select State!")
        }
        console.log("school",data)
        setErrorMessage(false);
        setSuccMessage(false);
        setSpinner(true);
        setUserdata(data);
        console.log(data)
        var min = 10000;
        var max = 99000;
        var rand =  Math.floor(Math.random() * (max - min) + min);
        setOtpsave(rand);
        const otp = {'otp':rand, 'email':data.email}
        API.api(otp,'auth/email-verification').then(res => {
          if(res){
            
              if(res.message==='Email Allready Exist!'){
                  setErrorMessage(true);
              }else{
                  setSuccMessageotp(true);
                  setEmailVHtml(true);
              }
              setSpinner(false)
          }else{
            console.log('error');
          }
        })
    }

    const onSubmitOTP = (data) => {
        console.log('jj',data)
        // data.school_collage=
        setErrorMessage(false);
        setSuccMessage(false);
        setRegistermsg(false);
        setSpinner(true);
        userdata.otp = otpsave;
        data.school_area_pin = localStorage.getItem('pin_code');
        data.state = state_id;
        API.api(data,'auth/register').then(res => {
          if(res){
            console.log('dsfds',res.message)
              if(res.message==='OTP Invalid'){
                  setOtpw('Invalid Otp');
              }else{
                  console.log('ffdfd')
                  setRegistermsg('Register Successfully');
                  setEmailVHtml(false);
              }
              setSpinner(false)
          }else{
            console.log('error');
          }
        })
    }

    const get_city_by_id=(id)=>{
        setState_id(id);
        const st_id  = {'id':id}
        API.api(st_id,'student/get-city').then(res => {
            if(res){
                setCity_data(res.result)
            }
          })
    }

    

    return (
        
        <div>
            <Header />
            <section>
                <div className="container">
                    <div className="batchmates-sec register-page">
                        <div className="img-sec">
                            
                            <div className="one-img">
                                <RegisterStudents/>
                            </div>
                            
                        </div>
                        
                        
                        {emailVHtml ? 
                        <div className="detail-form-sec">
                        
                        <h2>Enter Email OTP</h2>
                        {otpw}
                        {errorMessage ?? <Message param={MESSAGE.existEmail} /> }
                        <Message param={MESSAGE.otp} />
                        <form onSubmit={handleSubmit(onSubmitOTP)}>
                            <div className="pwd-sec">
                                <label>Enter your OTP</label>
                                <input id="emailotp" {...register("emailotp", { required: true })} type="password" />
                                <span><i className="fa fa-lock" aria-hidden="true"></i></span>
                            </div>
                            
                            <div className="btn-sec">
                            {spinner ?
                                <Watch
                                    height="50"
                                    width="50"
                                    color='red'
                                    ariaLabel='loading'
                                />
                                :
                                <button>Confirm</button>
                            }
                            </div>
                            
                        </form>
                        
                    </div>
                        :
                    
                        <div className="detail-form-sec">
                            <Popup/>
                            <h2>REGISTER NOW</h2>
                            <FlashMessage duration={5000}>
                                <strong style={{color:'green'}}>{registermsg}</strong>
                            </FlashMessage>
                            
                            {errorMessage ?
                                <Message param={MESSAGE.existEmail} />
                                :
                                succMessage?
                                <Message param={MESSAGE.register} />
                                :
                                ''
                            }
                            <form onSubmit={handleSubmit(onSubmit)}>
                                <div className="name">
                                    <label>Full name:</label>
                                    <input id="name" {...register("full_name", { required: "Enter your full name!" })} type="text" placeholder="Enter name"/>
                                    <div className="error-msg">
                                    <ErrorMessage style={{color:'red'}} errors={errors} name="full_name" />
                                </div>
                                </div>
                                
                              <div className="sch-coll">
                                <label>School/College Name:</label>
                               
                                   <Autocomplete
                                      id="school_collage"
                                      freeSolo
                                       options={schoole_data.map((option) => option.school_name)}
                                       renderInput={(params) => <TextField 
                                        {...register("school_collage",
                                      { required: "Enter your school name!" })} {...params}
                                       placeholder="Enter School Name"
                                      />}
                                  />
                                <div className="error-msg">
                                    <ErrorMessage style={{color:'red'}} errors={errors} name="school_collage" />
                                </div>
                                
                                </div>
                                <div className="batch-year">
                                    <label>Batch Year:</label>
                                    <select  id="year" {...register("batch_year", { required: "Select your batch year!" })} >
                                        <option value="">select</option>
                                        <option value="2010">2010</option>
                                        <option value="2011">2011</option>
                                        <option value="2012">2012</option>
                                        <option value="2013">2013</option>
                                        <option value="2013">2014</option>
                                        <option value="2013">2015</option>
                                        <option value="2013">2014</option>
                                        <option value="2013">2017</option>
                                        <option value="2013">2018</option>
                                        <option value="2013">2019</option>
                                        <option value="2013">2020</option>
                                        <option value="2013">2021</option>
                                        <option value="2013">2022</option>
                                    </select>
                                    <div className="error-msg">
                                    <ErrorMessage style={{color:'red'}} errors={errors} name="batch_year" />
                                </div>
                                </div>

                                <div className="state-sec">
                                    <label>State:</label>
                                    <select onChange={(e)=>{get_city_by_id(e.target.value)}}   id="state">
                                        
                                        {state_data ? 
                                            state_data.map((state,index)=>{
                                            return (<option value={state.id}>{state.state_name}</option>)
                                        })
                                        :
                                        ''
                                        }
                                    </select>
                                    <div className="error-msg">
                                    
                                    
                                    </div>
                                </div>

                                <div className="city-sec">
                                    <label>Which City?</label>
                                    <select  {...register("city", { required: "Select your city name!" })} id="city">
                                        <option value="">select</option>
                                        {city_data ? 
                                            city_data.map((city,index)=>{
                                            return (<option value={city.id}>{city.city_name}</option>)
                                        })
                                        :
                                        ''
                                        }
                                    </select>
                                    <div className="error-msg">
                                    <ErrorMessage style={{color:'red'}} errors={errors} name="city" />
                                </div>
                                </div>
                                
                                

                                <div className="email-sec">
                                    <label>Email:</label>
                                    <input {...register("email", { required:"Enter Your Email",pattern:{
                                           value: /\S+@\S+\.\S+/,
                                               message: "Entered value does not match email format"
                                    }
                                    })} type="email" id="email" />
                                    <span><i className="fa fa-user-o" aria-hidden="true"></i></span>
                                    <div className="error-msg">
                                    <ErrorMessage style={{color:'red'}} errors={errors} name="email" />
                                    </div>
                                </div>

                                <div className="pwd-sec">
                                    <label>Password:</label>
                                    <input id="password" {...register("password",
                                     { required: "Enter your password" ,minLength:{
                                         value:4,
                                         message:"Password must be more then 4 characters"
                                     },maxLength:{
                                        value:9   ,
                                        message:"Password must be Less then 10 characters"
                                    },}
                                )} type="password" />
                                     
                                    <span><i className="fa fa-lock" aria-hidden="true"></i></span>
                                    <div className="error-msg">
                                    <ErrorMessage style={{color:'red'}} errors={errors} name="password" />
                                    </div>
                                </div>

                                
                                
                                <div className="btn-sec">
                                {spinner ?
                                    <Watch
                                        height="50"
                                        width="50"
                                        color='red'
                                        ariaLabel='loading'
                                    />
                                    :
                                    <button>Submit</button>
                                }
                                </div>
                                
                            </form>
                            
                        </div>
                        }
                    </div>
                </div>
            </section>
        </div>
    );
}

  
  
export default Register;
